# Shared by the installer and its filesystem regression tests.
function Hash([string]$path) {
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Copy-Verified([string]$source, [string]$destination) {
    [IO.Directory]::CreateDirectory((Split-Path -Parent $destination)) | Out-Null
    [IO.File]::Copy($source, $destination, $true)
    if ((Hash $source) -ne (Hash $destination)) { throw "Copy verification failed: $destination" }
}
function Remove-TransferTemporary([string]$path) {
    # Cleanup must not mask an installation failure or undo a verified success.
    try {
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -ErrorAction Stop }
    } catch { Write-Warning "Could not remove temporary file '$path': $($_.Exception.Message)" }
}
function Replace-Verified([string]$source, [string]$destination) {
    if ([string]::IsNullOrWhiteSpace($source) -or [string]::IsNullOrWhiteSpace($destination)) {
        throw 'Replacement source and destination must be nonempty file paths.'
    }
    $source = [IO.Path]::GetFullPath($source)
    $destination = [IO.Path]::GetFullPath($destination)
    $transferId = [Guid]::NewGuid().ToString('N')
    $staged = $destination + '.' + $transferId + '.new'
    $previous = $destination + '.' + $transferId + '.previous'
    $verified = $false
    try {
        Copy-Verified $source $staged
        $expectedHash = Hash $staged
        if (Test-Path -LiteralPath $destination) {
            # Windows PowerShell can coerce $null to an empty string here.
            # Supply a real backup path on the same volume instead.
            [IO.File]::Replace($staged, $destination, $previous)
        } else { [IO.File]::Move($staged, $destination) }
        if ((Hash $destination) -ne $expectedHash) { throw 'Installed bytes differ from the verified staged file.' }
        $verified = $true
    } catch {
        $failure = $_
        if (Test-Path -LiteralPath $previous) {
            Write-Warning "Replacement failed. Previous file retained at: $previous"
        }
        throw "Cannot replace '$destination': $($failure.Exception.Message)"
    } finally {
        Remove-TransferTemporary $staged
        # Keep the previous file for recovery whenever replacement/verification failed.
        if ($verified) { Remove-TransferTemporary $previous }
    }
}
