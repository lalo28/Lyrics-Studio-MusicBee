﻿param(
    [ValidateSet('Build','Install','Restore')][string]$Mode = 'Build',
    [string]$PluginDirectory = ''
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$musicBeeData = Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'MusicBee'
$backupRoot = Join-Path $musicBeeData 'LyricsStudio\Backups'
$receiptPath = Join-Path $backupRoot 'LAST_RC_INSTALL.txt'
$logFolder = Join-Path $root 'validation'
[IO.Directory]::CreateDirectory($logFolder) | Out-Null
$logPath = Join-Path $logFolder ('release-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.log')

function Assert-Closed {
    if (Get-Process -Name MusicBee -ErrorAction SilentlyContinue) {
        throw 'Close MusicBee completely before installing or restoring.'
    }
}
. (Join-Path $PSScriptRoot 'FileOperations.ps1')
. (Join-Path $PSScriptRoot 'ReleaseState.ps1')
function Assert-Package {
    $manifest = [IO.File]::ReadAllLines((Join-Path $root 'SHA256SUMS.txt'))
    if ($manifest.Length -lt 10) { throw 'Package manifest is empty or incomplete.' }
    foreach ($line in $manifest) {
        if ($line -notmatch '^([a-f0-9]{64})  (.+)$') { throw 'Malformed package manifest.' }
        $expected = $Matches[1]; $relative = $Matches[2].Replace('/', '\')
        $path = [IO.Path]::GetFullPath((Join-Path $root $relative))
        if (-not $path.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe manifest path.' }
        if ((Hash $path) -ne $expected) { throw "Package checksum mismatch: $relative" }
    }
}
function Build-Release {
    Assert-Package
    & (Join-Path $root 'tests\InstallerRegression.ps1')
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
    if (-not (Test-Path -LiteralPath $compiler)) { throw '.NET Framework 4.x compiler missing; installation cancelled. No DLL was changed.' }
    $work = Join-Path $env:TEMP ('LyricsStudio-build-' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($work) | Out-Null
    $dll = Join-Path $work 'MB_TTMLLyrics.dll'
    $references = @('System.dll','System.Core.dll','System.Drawing.dll','System.Windows.Forms.dll','System.Xml.dll','System.Xml.Linq.dll','System.Web.Extensions.dll')
    $compileArgs = @('/nologo','/codepage:65001','/target:library','/platform:x86','/optimize+','/warn:4',('/out:' + $dll))
    $compileArgs += $references | ForEach-Object { '/reference:' + $_ }
    $compileArgs += '/resource:' + (Join-Path $root 'assets\playback_walkman\walkman_core_atlas.png') + ',LyricsStudio.Playback.WalkmanCoreAtlasV23522'
    $compileArgs += '/resource:' + (Join-Path $root 'assets\playback_walkman\walkman_bubbles_atlas.png') + ',LyricsStudio.Playback.WalkmanBubblesAtlasV23522'
    $compileArgs += Join-Path $root 'src\MB_TTMLLyrics.cs'
    & $compiler @compileArgs | Out-Host
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $dll)) { throw 'Plugin compilation failed; installation cancelled.' }
    if ([Reflection.AssemblyName]::GetAssemblyName($dll).ProcessorArchitecture.ToString() -ne 'X86') { throw 'The plugin is not x86.' }
    $testExe = Join-Path $work 'ReleaseRegression.exe'
    $testArgs = @('/nologo','/codepage:65001','/target:exe','/platform:x86','/warn:4',('/out:' + $testExe))
    $testArgs += $references | ForEach-Object { '/reference:' + $_ }
    $testArgs += Join-Path $root 'tests\ReleaseRegression.cs'
    & $compiler @testArgs | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'Regression harness compilation failed.' }
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $testExe
    $start.Arguments = '"' + $dll + '" "' + (Join-Path $work 'test-data') + '"'
    $start.UseShellExecute = $false
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = New-Object Diagnostics.Process
    $process.StartInfo = $start
    try {
        [void]$process.Start()
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(60000)) { $process.Kill(); throw 'Regression tests timed out; installation cancelled.' }
        Write-Host $stdout.Result
        Write-Host $stderr.Result
        if ($process.ExitCode -ne 0) { throw 'Regression tests failed; installation cancelled.' }
    } finally { $process.Dispose() }
    $destination = Join-Path $root 'dist\MB_TTMLLyrics.dll'
    Copy-Verified $dll $destination
    Write-Host "BUILD + REGRESSION PASS. DLL SHA256: $(Hash $destination)"
    Write-Host 'MusicBee playback, visual output and FPS still require manual acceptance.'
    return $destination
}
function Install-Release([string]$dll) {
    Assert-Closed
    $targetFolder = $PluginDirectory
    if ([string]::IsNullOrWhiteSpace($targetFolder)) { $targetFolder = Join-Path $musicBeeData 'Plugins' }
    $targetFolder = [IO.Path]::GetFullPath($targetFolder)
    if (-not (Test-Path -LiteralPath $targetFolder -PathType Container)) {
        throw 'Plugins folder not found. For portable MusicBee pass -PluginDirectory with its existing Plugins folder.'
    }
    $target = Join-Path $targetFolder 'MB_TTMLLyrics.dll'
    $backup = Join-Path $backupRoot ('RC-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($backup) | Out-Null
    $hadDll = Test-Path -LiteralPath $target
    if ($hadDll) { Copy-Verified $target (Join-Path $backup 'MB_TTMLLyrics.dll') }
    Backup-Configuration $backup $musicBeeData
    $previousHash = if ($hadDll) { Hash (Join-Path $backup 'MB_TTMLLyrics.dll') } else { '' }
    @{ PluginDirectory=$targetFolder; HadDll=$hadDll; PreviousHash=$previousHash; Schema=2; Version='23.55.0-rc2e-apple-auto-focus-contrast'; InstalledHash=(Hash $dll) } |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backup 'receipt.json') -Encoding UTF8
    Assert-Closed
    $receiptSource = Join-Path $backup 'restore-path.txt'
    [IO.File]::WriteAllText($receiptSource, $backup)
    Write-BackupManifest $backup
    $operations = New-Object 'System.Collections.Generic.List[object]'
    $operations.Add(@{ Source=$dll; Destination=$target; Remove=$false })
    $operations.Add(@{ Source=$receiptSource; Destination=$receiptPath; Remove=$false })
    $appleProfileSource = Join-Path $root 'profiles\AppleMusic'
    $appleProfileDestination = Join-Path $musicBeeData 'LyricsStudio\Profiles'
    foreach ($profile in Get-ChildItem -LiteralPath $appleProfileSource -File -Filter '*.lyricsprofile.json') {
        $operations.Add(@{ Source=$profile.FullName; Destination=(Join-Path $appleProfileDestination $profile.Name); Remove=$false })
    }
    $recovery = Join-Path $backupRoot ('Install-recovery-' + [Guid]::NewGuid().ToString('N'))
    Invoke-VerifiedFileTransaction ($operations.ToArray()) $recovery
    Write-Host "RC installed. Backup: $backup"
    Write-Host 'Open MusicBee and run the short checks in RELEASE_CHECKLIST.md before treating this as stable.'
}
function Restore-Release {
    Assert-Closed
    $backup = [IO.Path]::GetFullPath([IO.File]::ReadAllText($receiptPath).Trim())
    $canonicalRoot = [IO.Path]::GetFullPath($backupRoot).TrimEnd('\')
    if (-not $backup.StartsWith($canonicalRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid backup receipt.' }
    $recovery = Join-Path $backupRoot ('Before-restore-' + [Guid]::NewGuid().ToString('N'))
    Restore-ReleaseFiles $backup $musicBeeData $recovery
    Write-Host "Previous DLL and backed-up settings restored. Pre-restore copy: $recovery"
    Write-Host 'New profile files created after installation are preserved; no personal profile was deleted.'
}

$transcript = $false
try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Run this gate on Windows with .NET Framework 4.5+.' }
    Start-Transcript -LiteralPath $logPath | Out-Null
    $transcript = $true
    Set-Location -LiteralPath $root
    Write-Host 'Lyrics Studio 23.55.0 RC2E - Apple Auto Focus + Contrast'
    if ($Mode -eq 'Restore') {
        Assert-Package
        & (Join-Path $root 'tests\InstallerRegression.ps1')
        Restore-Release
    }
    else {
        if ($Mode -eq 'Install') { Assert-Closed }
        $builtDll = Build-Release
        if ($Mode -eq 'Install') { Install-Release $builtDll }
    }
    Write-Host "Log: $logPath"
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host $_.InvocationInfo.PositionMessage
    Write-Host "No further changes will be attempted. Details: $logPath"
    exit 1
} finally {
    if ($transcript) { Stop-Transcript | Out-Null }
}
