# RC2 state transactions. All paths are explicit so tests use only TEMP.
function Backup-Configuration([string]$destination, [string]$dataFolder) {
    foreach ($name in @('MB_TTMLLyrics.ini','MB_TTMLLyrics.offsets.ini')) {
        $path = Join-Path $dataFolder $name
        if (Test-Path -LiteralPath $path) { Copy-Verified $path (Join-Path $destination $name) }
    }
    foreach ($name in @('Profiles','ProfileOverrides')) {
        $folder = Join-Path $dataFolder ('LyricsStudio\' + $name)
        if (Test-Path -LiteralPath $folder) {
            foreach ($file in Get-ChildItem -LiteralPath $folder -File -Filter '*.lyricsprofile.json') {
                Copy-Verified $file.FullName (Join-Path $destination ($name + '\' + $file.Name))
            }
        }
    }
}

function Write-BackupManifest([string]$folder) {
    $folder = [IO.Path]::GetFullPath($folder).TrimEnd('\')
    $files = @(Get-ChildItem -LiteralPath $folder -File -Recurse | Where-Object { $_.Name -ne 'backup-files.json' } | ForEach-Object {
        @{ Path=$_.FullName.Substring($folder.Length + 1); Sha256=(Hash $_.FullName) }
    })
    @{ Schema=1; Files=$files } | ConvertTo-Json -Depth 5 |
        Set-Content -LiteralPath (Join-Path $folder 'backup-files.json') -Encoding UTF8
}

function Read-VerifiedBackup([string]$folder) {
    $folder = [IO.Path]::GetFullPath($folder).TrimEnd('\')
    $receipt = Get-Content -LiteralPath (Join-Path $folder 'receipt.json') -Raw | ConvertFrom-Json
    $manifestPath = Join-Path $folder 'backup-files.json'
    if (Test-Path -LiteralPath $manifestPath) {
        $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
        if ($manifest.Schema -ne 1) { throw 'Unsupported backup manifest.' }
        $verified = @{}
        foreach ($entry in $manifest.Files) {
            $path = [IO.Path]::GetFullPath((Join-Path $folder $entry.Path))
            if (-not $path.StartsWith($folder + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe backup path.' }
            if ($verified.ContainsKey($path)) { throw 'Duplicate backup entry.' }
            if ((Hash $path) -ne $entry.Sha256) { throw "Backup checksum mismatch: $($entry.Path)" }
            $verified[$path] = $true
        }
        foreach ($file in Get-ChildItem -LiteralPath $folder -File -Recurse) {
            if ($file.FullName -ne $manifestPath -and -not $verified.ContainsKey($file.FullName)) {
                throw "Unverified file in backup: $($file.Name)"
            }
        }
    } elseif ($null -ne $receipt.PSObject.Properties['Schema'] -and $receipt.Schema -ge 2) {
        throw 'RC2 backup manifest is missing; restore cancelled.'
    } else {
        Write-Warning 'Legacy RC1 backup: only the original DLL has a recorded checksum.'
    }
    if ($receipt.HadDll -and (Hash (Join-Path $folder 'MB_TTMLLyrics.dll')) -ne $receipt.PreviousHash) {
        throw 'Backup DLL checksum mismatch; restore cancelled.'
    }
    return $receipt
}

function Invoke-VerifiedFileTransaction([object[]]$operations, [string]$recovery) {
    [IO.Directory]::CreateDirectory($recovery) | Out-Null
    $records = New-Object 'System.Collections.Generic.List[object]'
    $destinations = @{}
    # Stage and verify every source and every previous destination before the first change.
    foreach ($operation in $operations) {
        if ([string]::IsNullOrWhiteSpace($operation.Destination)) { throw 'Empty transaction destination.' }
        $destination = [IO.Path]::GetFullPath($operation.Destination)
        if ($destinations.ContainsKey($destination)) { throw 'Duplicate transaction destination.' }
        $destinations[$destination] = $true
        $index = $records.Count.ToString('D4')
        $before = Join-Path $recovery ('before-' + $index)
        $staged = Join-Path $recovery ('source-' + $index)
        $hadFile = Test-Path -LiteralPath $destination
        $beforeHash = ''
        if ($hadFile) { Copy-Verified $destination $before; $beforeHash = Hash $before }
        if (-not $operation.Remove) { Copy-Verified $operation.Source $staged }
        $records.Add([pscustomobject]@{
            Destination=$destination; Before=$before; BeforeHash=$beforeHash; HadFile=$hadFile;
            Source=$staged; Remove=[bool]$operation.Remove; Index=$index
        })
    }
    # If this write fails, no live file has changed.
    @($records.ToArray()) | ConvertTo-Json -Depth 5 |
        Set-Content -LiteralPath (Join-Path $recovery 'transaction.json') -Encoding UTF8
    $attempted = New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($record in $records) {
            $exists = Test-Path -LiteralPath $record.Destination
            if ($exists -ne $record.HadFile -or ($exists -and (Hash $record.Destination) -ne $record.BeforeHash)) {
                throw "Destination changed since backup: $($record.Destination)"
            }
            $attempted.Add($record)
            if ($record.Remove) {
                if ($exists) { [IO.File]::Move($record.Destination, (Join-Path $recovery ('removed-' + $record.Index))) }
            } else { Replace-Verified $record.Source $record.Destination }
        }
    } catch {
        $failure = $_
        $recoveryErrors = New-Object 'System.Collections.Generic.List[string]'
        for ($i = $attempted.Count - 1; $i -ge 0; $i--) {
            $record = $attempted[$i]
            try {
                $exists = Test-Path -LiteralPath $record.Destination
                if ($record.HadFile) {
                    if (-not $exists -or (Hash $record.Destination) -ne $record.BeforeHash) {
                        Replace-Verified $record.Before $record.Destination
                    }
                } elseif ($exists) {
                    [IO.File]::Move($record.Destination, (Join-Path $recovery ('failed-created-' + $record.Index)))
                }
            } catch { $recoveryErrors.Add($record.Destination + ': ' + $_.Exception.Message) }
        }
        if ($recoveryErrors.Count -gt 0) {
            throw ($failure.Exception.Message + '. Automatic recovery incomplete: ' + ($recoveryErrors -join '; ') + '. Recovery files: ' + $recovery)
        }
        throw ($failure.Exception.Message + '. Transaction rolled back. Recovery files: ' + $recovery)
    }
}

function Restore-ReleaseFiles([string]$backup, [string]$dataFolder, [string]$recovery) {
    $receipt = Read-VerifiedBackup $backup
    $operations = New-Object 'System.Collections.Generic.List[object]'
    $operations.Add(@{ Source=(Join-Path $backup 'MB_TTMLLyrics.dll'); Destination=(Join-Path $receipt.PluginDirectory 'MB_TTMLLyrics.dll'); Remove=(-not $receipt.HadDll) })
    foreach ($name in @('MB_TTMLLyrics.ini','MB_TTMLLyrics.offsets.ini')) {
        $source = Join-Path $backup $name
        if (Test-Path -LiteralPath $source) {
            $operations.Add(@{ Source=$source; Destination=(Join-Path $dataFolder $name); Remove=$false })
        }
    }
    foreach ($name in @('Profiles','ProfileOverrides')) {
        $folder = Join-Path $backup $name
        if (Test-Path -LiteralPath $folder) {
            foreach ($file in Get-ChildItem -LiteralPath $folder -File -Filter '*.lyricsprofile.json') {
                $operations.Add(@{ Source=$file.FullName; Destination=(Join-Path $dataFolder ('LyricsStudio\' + $name + '\' + $file.Name)); Remove=$false })
            }
        }
    }
    Invoke-VerifiedFileTransaction ($operations.ToArray()) $recovery
}
