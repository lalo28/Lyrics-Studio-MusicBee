# Executes the exact PowerShell file-transfer functions used for installation.
# All files are isolated under TEMP; no MusicBee file or setting is touched.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw 'Installer regression must run on Windows.'
}
. (Join-Path (Split-Path -Parent $PSScriptRoot) 'scripts\FileOperations.ps1')
. (Join-Path (Split-Path -Parent $PSScriptRoot) 'scripts\ReleaseState.ps1')

function Assert-Installer([bool]$condition, [string]$message) {
    if (-not $condition) { throw "Installer regression failed: $message" }
    Write-Host "PASS INSTALLER: $message"
}
function Assert-NoTransferFiles([string]$folder) {
    $remaining = @(Get-ChildItem -LiteralPath $folder -File -Recurse | Where-Object {
        $_.Name -match '\.[0-9a-f]{32}\.(new|previous)$'
    })
    Assert-Installer ($remaining.Count -eq 0) 'no transfer temporaries left'
}

function Test-ReleaseState([string]$folder) {
    $data = Join-Path $folder 'state\MusicBee data'
    $plugins = Join-Path $folder 'state\Plugins'
    $backup = Join-Path $folder 'state\Backup'
    [IO.Directory]::CreateDirectory($plugins) | Out-Null
    [IO.Directory]::CreateDirectory((Join-Path $data 'LyricsStudio\Profiles')) | Out-Null
    $dll = Join-Path $plugins 'MB_TTMLLyrics.dll'
    $ini = Join-Path $data 'MB_TTMLLyrics.ini'
    $offsets = Join-Path $data 'MB_TTMLLyrics.offsets.ini'
    $profile = Join-Path $data 'LyricsStudio\Profiles\test.lyricsprofile.json'
    $files = @($dll,$ini,$offsets,$profile)
    foreach ($file in $files) { [IO.File]::WriteAllText($file, 'old:' + $file) }
    Copy-Verified $dll (Join-Path $backup 'MB_TTMLLyrics.dll')
    Backup-Configuration $backup $data
    @{ Schema=2; PluginDirectory=$plugins; HadDll=$true; PreviousHash=(Hash $dll) } |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backup 'receipt.json') -Encoding UTF8
    Write-BackupManifest $backup
    Assert-Installer (Test-Path -LiteralPath (Join-Path $backup 'MB_TTMLLyrics.offsets.ini')) 'configuration backup includes song offsets'
    foreach ($file in $files) { [IO.File]::WriteAllText($file, 'current:' + $file) }
    $newProfile = Join-Path $data 'LyricsStudio\Profiles\created-after-install.lyricsprofile.json'
    [IO.File]::WriteAllText($newProfile, 'personal profile')

    # Share.Read allows all preflight backups/hashes, but denies Replace/Delete.
    # These failures therefore happen after earlier replacements really occurred.
    foreach ($lockedPath in @($ini,$offsets,$profile)) {
        $handle = [IO.File]::Open($lockedPath, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
        $failure = ''
        try {
            try { Restore-ReleaseFiles $backup $data (Join-Path $folder ('rollback-' + [Guid]::NewGuid().ToString('N'))) }
            catch { $failure = $_.Exception.Message }
        } finally { $handle.Dispose() }
        Assert-Installer ($failure.Contains('Transaction rolled back')) 'restore failure rolls back earlier files'
        foreach ($file in $files) {
            Assert-Installer ([IO.File]::ReadAllText($file) -eq ('current:' + $file)) 'failed restore preserves entire previous installation'
        }
    }

    $backedProfile = Join-Path $backup 'Profiles\test.lyricsprofile.json'
    $original = [IO.File]::ReadAllText($backedProfile)
    [IO.File]::WriteAllText($backedProfile, 'corrupted backup')
    $rejected = $false
    try { Restore-ReleaseFiles $backup $data (Join-Path $folder 'corrupt-restore') } catch { $rejected = $true }
    Assert-Installer $rejected 'corrupt configuration backup rejects restore before changing the DLL'
    Assert-Installer ([IO.File]::ReadAllText($dll) -eq ('current:' + $dll)) 'corrupt backup preserves current DLL'
    [IO.File]::WriteAllText($backedProfile, $original)

    Restore-ReleaseFiles $backup $data (Join-Path $folder 'successful-restore')
    foreach ($file in $files) { Assert-Installer ([IO.File]::ReadAllText($file) -eq ('old:' + $file)) 'complete restore returns DLL, settings, offsets and profiles' }
    Assert-Installer ([IO.File]::ReadAllText($newProfile) -eq 'personal profile') 'restore preserves profiles created after installation'

    $manifest = Join-Path $backup 'backup-files.json'
    [IO.File]::Move($manifest, $manifest + '.hold')
    $rejected = $false
    try { Read-VerifiedBackup $backup | Out-Null } catch { $rejected = $true }
    Assert-Installer $rejected 'RC2 backup without its manifest is rejected'
    [IO.File]::Move($manifest + '.hold', $manifest)

    # First installation: failure writing its receipt must remove the newly created DLL.
    $newDll = Join-Path $plugins 'first-install.dll'
    $receipt = Join-Path $folder 'locked-receipt.txt'
    [IO.File]::WriteAllText($receipt, 'previous receipt')
    $handle = [IO.File]::Open($receipt, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    $failure = ''
    try {
        $operations = @(
            @{ Source=$dll; Destination=$newDll; Remove=$false },
            @{ Source=$ini; Destination=$receipt; Remove=$false }
        )
        try { Invoke-VerifiedFileTransaction $operations (Join-Path $folder 'install-rollback') }
        catch { $failure = $_.Exception.Message }
    } finally { $handle.Dispose() }
    Assert-Installer ($failure.Contains('Transaction rolled back') -and -not (Test-Path -LiteralPath $newDll)) 'failed first install leaves no new DLL'
    Assert-Installer ([IO.File]::ReadAllText($receipt) -eq 'previous receipt') 'failed installation preserves old restore receipt'

    $legacy = Join-Path $folder 'legacy-backup'
    Copy-Verified $dll (Join-Path $legacy 'MB_TTMLLyrics.dll')
    @{ PluginDirectory=$plugins; HadDll=$true; PreviousHash=(Hash $dll) } |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $legacy 'receipt.json') -Encoding UTF8
    $legacyReceipt = Read-VerifiedBackup $legacy
    Assert-Installer ($legacyReceipt.HadDll) 'existing RC1 backups remain readable'
}

$sandbox = Join-Path ([IO.Path]::GetTempPath()) ('LyricsStudio-installer-test-' + [Guid]::NewGuid().ToString('N'))
$succeeded = $false
try {
    # Keep the script ASCII for Windows PowerShell; construct Unicode filenames.
    $folder = Join-Path $sandbox ('MusicBee [test] ' + [char]0x00E1 + ' ' + [char]0x6B4C)
    [IO.Directory]::CreateDirectory($folder) | Out-Null
    $oldSource = Join-Path $folder 'old plugin.dll'
    $newSource = Join-Path $folder 'new plugin.dll'
    $target = Join-Path $folder 'Plugins\MB_TTMLLyrics.dll'
    $oldBytes = [byte[]](0, 1, 2, 255, 0, 17)
    $newBytes = [byte[]](254, 0, 31, 45, 0, 99, 128, 5)
    [IO.File]::WriteAllBytes($oldSource, $oldBytes)
    [IO.File]::WriteAllBytes($newSource, $newBytes)

    # First install creates the Plugins directory and destination.
    Replace-Verified $oldSource $target
    Assert-Installer ((Hash $target) -eq (Hash $oldSource)) 'first install in a path with spaces, brackets and Unicode'
    Assert-NoTransferFiles $folder

    # This is the path missed by the C# regression harness: .NET called from PS.
    Replace-Verified $newSource $target
    Assert-Installer ((Hash $target) -eq (Hash $newSource)) 'atomic replacement of an existing DLL from PowerShell'
    Assert-Installer ([IO.File]::ReadAllBytes($newSource).Length -eq $newBytes.Length) 'replacement preserves its source'
    Assert-NoTransferFiles $folder

    # The same primitive is also used for the restore receipt on repeated installs.
    $receiptSource = Join-Path $folder 'restore-path.txt'
    $receipt = Join-Path $folder 'Backups\LAST_RC_INSTALL.txt'
    [IO.File]::WriteAllText($receiptSource, (Join-Path $folder 'RC-first'))
    Replace-Verified $receiptSource $receipt
    Assert-Installer ((Hash $receipt) -eq (Hash $receiptSource)) 'first restore receipt'
    [IO.File]::WriteAllText($receiptSource, (Join-Path $folder 'RC-second'))
    Replace-Verified $receiptSource $receipt
    Assert-Installer ([IO.File]::ReadAllText($receipt) -eq (Join-Path $folder 'RC-second')) 'replacement of an existing restore receipt'

    Replace-Verified $oldSource $target
    Assert-Installer ((Hash $target) -eq (Hash $oldSource)) 'previous DLL can be restored'

    $lockedFailure = $false
    $handle = [IO.File]::Open($target, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::None)
    try {
        try { Replace-Verified $newSource $target }
        catch { $lockedFailure = $true }
    } finally { $handle.Dispose() }
    Assert-Installer $lockedFailure 'locked destination rejects replacement'
    Assert-Installer ((Hash $target) -eq (Hash $oldSource)) 'locked destination retains original bytes'
    Assert-NoTransferFiles $folder

    $missingFailure = $false
    try { Replace-Verified (Join-Path $folder 'missing.dll') $target }
    catch { $missingFailure = $true }
    Assert-Installer $missingFailure 'missing source rejects replacement'
    Assert-Installer ((Hash $target) -eq (Hash $oldSource)) 'missing source leaves installed DLL intact'
    Assert-NoTransferFiles $folder
    Test-ReleaseState $folder
    Assert-NoTransferFiles $folder
    $succeeded = $true
    Write-Host 'INSTALLER REGRESSION PASS. MusicBee files were not touched.'
} finally {
    if ($succeeded) {
        try { Remove-Item -LiteralPath $sandbox -Recurse -Force -ErrorAction Stop }
        catch { Write-Warning "Installer test cleanup failed: $sandbox" }
    } else { Write-Host "Installer test data retained for diagnosis: $sandbox" }
}
