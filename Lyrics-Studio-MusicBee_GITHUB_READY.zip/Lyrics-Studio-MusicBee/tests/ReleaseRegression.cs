﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;

// Executes against the compiled plugin, without MusicBee, playback, network or user settings.
internal static class ReleaseRegression
{
    private const BindingFlags All = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
    private static Type plugin, settingsType, viewType, storeType;
    private static int checks;
    private static object Call(Type type, object instance, string name, params object[] args)
    {
        try { return type.GetMethod(name, All).Invoke(instance, args); }
        catch (TargetInvocationException e) { throw e.InnerException ?? e; }
    }
    private static object Settings()
    {
        object s = Activator.CreateInstance(settingsType, true);
        Call(settingsType, s, "ResetVisualDefaults");
        return s;
    }
    private static void Set(object o, string field, object value) { o.GetType().GetField(field, All).SetValue(o, value); }
    private static object Get(object o, string field) { return o.GetType().GetField(field, All).GetValue(o); }
    private static void Check(bool condition, string label)
    {
        if (!condition) throw new Exception("FAIL: " + label);
        checks++;
        Console.WriteLine("PASS: " + label);
    }
    private static void Reject(Action action, string label)
    {
        bool rejected = false;
        try { action(); } catch { rejected = true; }
        Check(rejected, label);
    }
    private static Dictionary<string, string> Export(object s)
    { return (Dictionary<string, string>)Call(settingsType, s, "ExportProfileDictionaryV23110"); }
    private static Dictionary<string, string> Parse(string json)
    {
        object[] args = new object[] { json, "Test", null };
        return (Dictionary<string, string>)Call(storeType, null, "ParseProfileJsonV23550", args);
    }

    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            Assembly dll = Assembly.LoadFrom(Path.GetFullPath(args[0]));
            plugin = dll.GetType("MusicBeePlugin.Plugin", true);
            settingsType = plugin.GetNestedType("PluginSettings", All);
            viewType = plugin.GetNestedType("LyricsView", All);
            storeType = plugin.GetNestedType("ProfileStore", All);
            string folder = Path.GetFullPath(args[1]);
            Directory.CreateDirectory(folder);
            Check((string)plugin.GetField("PluginVersionText", All).GetRawConstantValue() == "23.55.0-rc2e-apple-auto-focus-contrast", "release version");
            TestProfiles(folder);
            TestLocalProfiles(folder);
            TestTrackOffsets(folder);
            TestTextElements();
            TestWrap();
            TestParsers();
            TestTtmlRanges();
            TestKaraokeClip();
            TestAtomicWrite(folder);
            Console.WriteLine("RESULT: " + checks + " checks passed. MusicBee visual acceptance NOT tested.");
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e.ToString()); return 1; }
    }

    private static void TestProfiles(string folder)
    {
        string[] visual = { "FontName", "WordFocusEffectV2329", "WordFocusSizePercentV2329",
            "TypographyFxDirectorV2323", "ArtworkThemeMode", "BackgroundEngineV23",
            "BackgroundMotionV23", "CustomBackgroundA", "CleanLyricsMode", "ViewZoomPercent" };
        string[] global = { "RendererBackendV236", "LyricsRenderPipelineV2364", "ReducedMotion",
            "GlobalOffsetMs", "DiagnosticOverlay", "FullscreenAutoGpuV2366", "OnlineProviderOrder" };
        foreach (string key in visual) Check(!(bool)Call(settingsType, null, "IsGlobalSettingKeyV23110", key), "profile owns " + key);
        foreach (string key in global) Check((bool)Call(settingsType, null, "IsGlobalSettingKeyV23110", key), "global owns " + key);
        object s = Settings();
        Set(s, "WordFocusEffectV2329", "Soft Halo"); Set(s, "ViewZoomPercent", 175);
        Set(s, "CustomBackgroundA", "#123456"); Set(s, "CleanLyricsMode", true);
        Set(s, "GlobalOffsetMs", 140); Set(s, "ReducedMotion", true);
        Call(settingsType, s, "ResetProfileOwnedStateV23110");
        object clean = Settings(); Call(settingsType, clean, "ResetProfileOwnedStateV23110");
        Dictionary<string, string> defaults = Export(clean), reset = Export(s);
        Check(defaults.All(delegate(KeyValuePair<string, string> kv) { return reset[kv.Key] == kv.Value; }), "complete reset has no visual residues");
        Check((int)Get(s, "GlobalOffsetMs") == 140 && (bool)Get(s, "ReducedMotion"), "reset preserves sync and accessibility");
        Set(s, "BackgroundModeV23120", "Recipe");
        Set(s, "ArtworkBackground", false);
        Set(s, "InstrumentalAnimation", false);
        Set(s, "InstrumentalCountdownStandalone", true);
        Set(s, "InstrumentalCountdown", true);
        Call(settingsType, s, "ApplyGlobalStateV23110", new Dictionary<string, string> { { "GlobalOffsetMs", "140" } });
        Check((string)Get(s, "BackgroundModeV23120") == "Recipe" && (bool)Get(s, "InstrumentalCountdownStandalone"),
            "restoring globals does not run missing-visual-key migration");
        Dictionary<string, string> incoming = new Dictionary<string, string> {
            {"FontName", "Spotify Mix UI Bold"}, {"WordFocusEffectV2329", "Off"},
            {"RendererBackendV236", "unsafe-test"}, {"GlobalOffsetMs", "900"} };
        string renderer = (string)Get(s, "RendererBackendV236");
        Call(settingsType, s, "ApplyProfileDictionaryV23110", incoming);
        Check((string)Get(s, "FontName") == "Roboto", "legacy font migrated before previews");
        Check((string)Get(s, "RendererBackendV236") == renderer && (int)Get(s, "GlobalOffsetMs") == 140, "profile cannot change backend or offset");
        Check((string)Call(plugin, null, "SafeFontRequestV23550", "Circular Std") == "Roboto", "Circular blocked");
        Check((string)Call(plugin, null, "SafeFontRequestV23550", "Inter") == "Inter", "other fonts preserved");
        string path = Path.Combine(folder, "test.lyricsprofile.json");
        Set(s, "ProfileParentName", "must-not-be-inherited");
        Set(s, "WordFocusEffectV2329", "Off");
        Call(storeType, null, "SaveFile", path, "Canción \"ñ\"", s);
        string first = File.ReadAllText(path);
        Set(s, "WordFocusEffectV2329", "Soft Halo");
        Call(storeType, null, "SaveFile", path, "Canción \"ñ\"", s);
        Check(File.ReadAllText(path + ".bak") == first, "previous profile saved as backup");
        Dictionary<string, string> saved = Parse(File.ReadAllText(path));
        Check(saved["ProfileParentName"] == "" && saved["WordFocusEffectV2329"] == "Soft Halo", "saved profile is full detached snapshot");
        object[] loadArgs = { path, null };
        Call(storeType, null, "LoadProfileDictionaryV23110", loadArgs);
        Check((string)loadArgs[1] == "Canción \"ñ\"", "Unicode and quotes round-trip");
        Check(Parse("{\"settings\":{\"FontName\":\"Sego\\u0065 UI\"}}")["FontName"] == "Segoe UI", "JSON Unicode escapes");
        Check(Parse("{\"settings\":{\"FontScale\":104,\"KaraokeEnabled\":true}}")["FontScale"] == "104", "legacy scalar values");
        Reject(delegate { Parse("{\"settings\":{\"FontScale\":\"bad\"}}"); }, "invalid number rejected");
        Reject(delegate { Parse("{\"settings\":{\"KaraokeEnabled\":\"maybe\"}}"); }, "invalid boolean rejected");
        Reject(delegate { Parse("{\"settings\":{\"FontName\":{}}}"); }, "nested setting rejected");
        Reject(delegate { Parse("{\"settings\":{\"FontName\":\"Inter\"}"); }, "truncated JSON rejected");
        Reject(delegate { Parse("{\"format\":\"other\",\"FontName\":\"Inter\"}"); }, "foreign format rejected");
        Reject(delegate { Parse("{\"settings\":{}}"); }, "empty profile rejected");
        Reject(delegate { Parse("{\"settings\":{\"FontName\":\"Inter\\nFontScale=199\"}}"); }, "INI injection rejected");
        Call(settingsType, s, "ApplyCpuV21TextOnlyStartupV2364");
        Check(!(bool)Get(s, "GpuAtmosphereV236") && !(bool)Get(s, "FullscreenAutoGpuV2366") &&
            !(bool)Get(s, "DxgiDirectPresentV2365"), "safe CPU startup");
        Call(settingsType, s, "ApplyLightweightStartupV228");
        Check((string)Get(s, "CurrentProfile") == "Studio Lite" && (string)Get(s, "WordFocusEffectV2329") == "Off" &&
            (string)Get(s, "ActiveLineSurfaceV2337") == "None", "fresh lightweight startup");
    }

    private static void TestLocalProfiles(string folder)
    {
        string profiles = Path.Combine(folder, "local-profiles");
        object s = Settings();
        Set(s, "FontName", "Roboto"); Set(s, "FontScale", 123); Set(s, "ProfileParentName", "old parent");
        string path = (string)Call(storeType, null, "SaveLocalInFolderV23550", profiles, "Canción azul", s, false);
        Check((string)Call(storeType, null, "FindLocalPathInFolderV23550", profiles, "Canción azul") == path, "registered local profile can be found after saving");
        object[] load = { path, null };
        object restored = Call(storeType, null, "LoadFile", load);
        Check((string)load[1] == "Canción azul" && (int)Get(restored, "FontScale") == 123 &&
            (string)Get(restored, "FontName") == "Roboto" && (string)Get(restored, "ProfileParentName") == "", "detached local profile reloads its saved settings");
        string original = File.ReadAllText(path);
        Reject(delegate { Call(storeType, null, "SaveLocalInFolderV23550", profiles, "CANCIÓN AZUL", s, false); }, "case collision requires explicit replacement");
        Check(File.ReadAllText(path) == original, "rejected duplicate preserves profile");
        foreach (string name in new string[] { "Mix:A", "Mix?A", "../outside", "CON", "aux.txt", "bad.", "Apple Flow", "Personalizado", "bad\nname" })
        {
            string invalid = name;
            Reject(delegate { Call(storeType, null, "SaveLocalInFolderV23550", profiles, invalid, s, false); }, "unsafe or reserved local name rejected: " + name.Replace('\n', ' '));
        }
        string legacy = Path.Combine(profiles, "Mix_A.lyricsprofile.json");
        Call(storeType, null, "SaveFile", legacy, "Mix:A", s);
        Check((string)Call(storeType, null, "FindLocalPathInFolderV23550", profiles, "Mix:A") == legacy, "legacy sanitized name remains readable");
        Check(Call(storeType, null, "FindLocalPathInFolderV23550", profiles, "Mix?A") == null, "legacy filename does not alias a different display name");
        Set(s, "FontScale", 145);
        Call(storeType, null, "SaveLocalInFolderV23550", profiles, "Canción azul", s, true);
        Check(File.ReadAllText(path + ".bak") == original, "explicit replacement preserves previous profile");
    }

    private static void TestTrackOffsets(string folder)
    {
        Type offsets = plugin.GetNestedType("TrackOffsetStore", All);
        string path = Path.Combine(folder, "offsets.ini");
        Dictionary<string, int> expected = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase) {
            { @"C:\a.mp3", 140 }, { @"C:\ab.mp3", -250 }, { @"C:\abc.mp3", 5000 },
            { @"C:\Música\Canción 歌.mp3", -5000 } };
        Call(offsets, null, "WriteOffsetsV23550", path, expected);
        Dictionary<string, int> actual = (Dictionary<string, int>)Call(offsets, null, "ReadOffsetsV23550", path);
        Check(actual.Count == expected.Count && expected.All(delegate(KeyValuePair<string, int> kv) { return actual[kv.Key] == kv.Value; }),
            "offsets survive disk reload: all Base64 padding cases, Unicode and signed values");
        string original = File.ReadAllText(path);
        expected.Remove(@"C:\a.mp3");
        Call(offsets, null, "WriteOffsetsV23550", path, expected);
        Check(File.ReadAllText(path + ".bak") == original, "offset update retains previous store");
        actual = (Dictionary<string, int>)Call(offsets, null, "ReadOffsetsV23550", path);
        Check(!actual.ContainsKey(@"C:\a.mp3") && actual.Count == 3, "removed offset stays removed after reload");
        string saved = File.ReadAllText(path);
        using (FileStream locked = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.None))
        {
            Reject(delegate { Call(offsets, null, "WriteOffsetsV23550", path, new Dictionary<string, int>()); }, "locked offset save reports failure");
            Reject(delegate { Call(offsets, null, "ReadOffsetsV23550", path); }, "unreadable offset store is not treated as empty");
        }
        Check(File.ReadAllText(path) == saved, "failed offset write preserves all songs");
    }

    private static void TestTtmlRanges()
    {
        Type parser = plugin.GetNestedType("LyricsParser", All);
        foreach (string first in new string[] { "  Hola ", "\n  Hola ", "<span>  Hola </span>" })
        {
            string xml = "<tt xmlns=\"http://www.w3.org/ns/ttml\"><body><div><p begin=\"00:00:01.000\" end=\"00:00:05.000\">" +
                "<span begin=\"00:00:01.000\" end=\"00:00:02.000\">" + first + "</span>" +
                "<span begin=\"00:00:02.000\" end=\"00:00:04.000\">mundo  </span></p></div></body></tt>";
            object parsed = Call(parser, null, "ParseText", xml, "TTML", 12000);
            object line = ((IList)Get(parsed, "Lines"))[0];
            IList segments = (IList)Get(line, "Segments");
            string text = (string)Get(line, "Text");
            Check(text == "Hola mundo" && segments.Count == 2, "TTML trims text without adding segments");
            Check((int)Get(segments[0], "StartChar") == 0 && (int)Get(segments[0], "Length") == 5 &&
                (int)Get(segments[1], "StartChar") == 5 && (int)Get(segments[1], "Length") == 5, "TTML trimmed spans have exact nonoverlapping ranges");
            Check((double)Get(segments[0], "BeginMs") == 1000 && (double)Get(segments[0], "EndMs") == 2000 &&
                (double)Get(segments[1], "BeginMs") == 2000 && (double)Get(segments[1], "EndMs") == 4000, "TTML trimming preserves word times");
        }
    }

    private static void TestKaraokeClip()
    {
        object view = FormatterServices.GetUninitializedObject(viewType);
        object s = Settings();
        Set(s, "KaraokeStyle", "Classic"); Set(s, "WordFocusEffectV2329", "Off");
        Set(s, "HighlightFeatherPro", false); Set(s, "MotionEngine2V2323", false);
        Set(s, "SyllablePulse", false); Set(s, "MelismaHold", false);
        Set(s, "CustomProfileColors", false); Set(s, "ActiveLineAnimation", "Original / Viewer Default");
        Set(view, "settings", s); Set(view, "activeColor", Color.White); Set(view, "hoverColor", Color.White);
        FieldInfo scratch = viewType.GetField("karaokePaintScratchV2390", All);
        scratch.SetValue(view, Activator.CreateInstance(scratch.FieldType));
        Type lineType = plugin.GetNestedType("LyricLine", All), segmentType = plugin.GetNestedType("LyricSegment", All);
        object line = Activator.CreateInstance(lineType, true);
        string text = "MMMMMMMM MMMM MMMMMMMM";
        Set(line, "Text", text);
        int[] starts = { 0, 9, 14 }, lengths = { 9, 5, 8 };
        for (int i = 0; i < starts.Length; i++)
        {
            object segment = Activator.CreateInstance(segmentType, true);
            Set(segment, "StartChar", starts[i]); Set(segment, "Length", lengths[i]);
            Set(segment, "BeginMs", i * 1000.0); Set(segment, "EndMs", i == 2 ? 4000.0 : (i + 1) * 1000.0);
            ((IList)Get(line, "Segments")).Add(segment);
        }
        object row = Activator.CreateInstance(viewType.GetNestedType("VisualRow", All), true);
        Set(row, "Text", text); Set(row, "Length", text.Length); Set(row, "StartChar", 0);
        foreach (double now in new double[] { 500.0, 3000.0 })
        using (Bitmap bitmap = new Bitmap(400, 90))
        using (Graphics g = Graphics.FromImage(bitmap))
        using (Font font = new Font("Segoe UI", 28f, FontStyle.Bold))
        {
            Rectangle safe = new Rectangle(90, 0, 80, 80);
            g.Clear(Color.Black); g.SetClip(safe);
            SizeF size = (SizeF)Call(viewType, null, "MeasureTypographic", g, text, font);
            Call(viewType, view, "DrawWrappedKaraokeSegmentsBatchedV23511", g, line, row, font, 0f, 5f, size, now);
            Check(g.ClipBounds == (RectangleF)safe, "karaoke restores the caller clip");
            int inside = 0, outside = 0;
            for (int y = 0; y < bitmap.Height; y++)
            for (int x = 0; x < bitmap.Width; x++)
                if (bitmap.GetPixel(x, y).ToArgb() != Color.Black.ToArgb())
                { if (safe.Contains(x, y)) inside++; else outside++; }
            Check(inside > 0 && outside == 0, "actual wrapped karaoke respects lyrics area: t=" + now);
        }
    }

    private static void TestTextElements()
    {
        string[] clusters = { "a\u0301", "\U0001F600", "\U0001F44D\U0001F3FD",
            "\U0001F469\u200D\U0001F4BB", "\U0001F1F2\U0001F1FD", "1\uFE0F\u20E3" };
        foreach (string cluster in clusters)
        {
            string text = cluster + cluster;
            int[] ends = (int[])Call(viewType, null, "SafeTextEndsV23550", text, 0, text.Length);
            Check(ends.SequenceEqual(new int[] { cluster.Length, text.Length }), "intact text elements: " + cluster);
        }
    }

    private static void TestWrap()
    {
        // No Control constructor, UI handle or MusicBee API. Only the real wrap methods.
        object view = FormatterServices.GetUninitializedObject(viewType);
        object s = Settings(); Set(view, "settings", s);
        string[] examples = { new string('W', 250), String.Concat(Enumerable.Repeat("a\u0301", 80)),
            String.Concat(Enumerable.Repeat("\U0001F600", 45)),
            String.Concat(Enumerable.Repeat("\U0001F469\u200D\U0001F4BB", 25)),
            "One fairly long sentence with several different words that must wrap without changing its characters." };
        foreach (int dpi in new int[] { 96, 120, 144, 192 })
        using (Bitmap bitmap = new Bitmap(800, 800))
        {
            bitmap.SetResolution(dpi, dpi);
            using (Graphics g = Graphics.FromImage(bitmap))
            using (Font font = new Font("Segoe UI", 26f, FontStyle.Bold))
            foreach (bool smart in new bool[] { false, true })
            {
                Set(s, "SmartWrappingPro", smart);
                foreach (string text in examples)
                {
                    IList rows = (IList)Call(viewType, view, "BuildBalancedRows", g, text, font, 95f);
                    int previousEnd = 0;
                    foreach (object row in rows)
                    {
                        int start = (int)Get(row, "StartChar"), length = (int)Get(row, "Length");
                        string value = (string)Get(row, "Text");
                        if (value != text.Substring(start, length) || start < previousEnd)
                            throw new Exception("Row offsets corrupted");
                        if (text.Substring(previousEnd, start - previousEnd).Any(delegate(char c) { return !Char.IsWhiteSpace(c); }))
                            throw new Exception("Characters lost between rows");
                        SizeF size = (SizeF)Call(viewType, null, "MeasureTypographic", g, value, font);
                        int[] boundaries = (int[])Call(viewType, null, "SafeTextEndsV23550", value, 0, value.Length);
                        if (size.Width > 95.5f && boundaries.Length > 1) throw new Exception("Row overflow");
                        previousEnd = start + length;
                    }
                    Check(previousEnd == text.Length, "wrap content, bounds and offsets DPI=" + dpi + " smart=" + smart);
                    object again = Call(viewType, view, "BuildBalancedRows", g, text, font, 95f);
                    Check(Object.ReferenceEquals(rows, again), "wrap cache reused");
                }
            }
        }
    }

    private static void TestAtomicWrite(string folder)
    {
        string path = Path.Combine(folder, "atomic.txt"), backup = path + ".bak";
        Call(plugin, null, "WriteTextAtomicallyV23550", path, "first", backup);
        Call(plugin, null, "WriteTextAtomicallyV23550", path, "second", backup);
        Check(File.ReadAllText(path) == "second" && File.ReadAllText(backup) == "first", "atomic replacement and backup");
        using (FileStream locked = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.None))
            Reject(delegate { Call(plugin, null, "WriteTextAtomicallyV23550", path, "bad", backup); }, "locked save fails safely");
        Check(File.ReadAllText(path) == "second", "failed save preserves live file");
        Check(Directory.GetFiles(folder, "*.tmp").Length == 0, "temporary saves cleaned");
    }

    private static void TestParsers()
    {
        Type parser = plugin.GetNestedType("LyricsParser", All);
        object lrc = Call(parser, null, "ParseText", "[00:01.00]Uno\n[00:04.00]Dos", "LRC", 12000);
        Check((bool)Get(lrc, "IsTimed") && ((IList)Get(lrc, "Lines")).Count == 2, "LRC smoke");
        object elrc = Call(parser, null, "ParseText", "[00:01.00]<00:01.00>Uno <00:02.00>dos\n[00:04.00]Final", "ELRC", 12000);
        Check((bool)Get(elrc, "IsWordTimed"), "ELRC smoke");
        object txt = Call(parser, null, "ParseText", "Uno\nDos", "TXT", 12000);
        Check(!(bool)Get(txt, "IsTimed") && ((IList)Get(txt, "Lines")).Count == 2, "TXT smoke");
        object instrumental = Call(parser, null, "ParseText", "[au: instrumental]", "LRC", 12000);
        Check((bool)Get(instrumental, "FullTrackInstrumental"), "instrumental smoke");
        string xml = "<tt xmlns=\"http://www.w3.org/ns/ttml\"><body><div><p begin=\"1s\" end=\"5s\"><span begin=\"1s\" end=\"2s\">Uno </span><span begin=\"2s\" end=\"5s\">dos</span></p></div></body></tt>";
        object ttml = Call(parser, null, "ParseText", xml, "TTML", 12000);
        Check((bool)Get(ttml, "IsWordTimed") && ((IList)Get(ttml, "Lines")).Count == 1, "TTML smoke");
    }
}
