﻿"""Portable source/package checks. This is NOT a C# compiler or a rendering test."""
from pathlib import Path
from functools import lru_cache
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

@lru_cache(maxsize=3)
def mask_csharp(text):
    result = list(text)
    i = 0
    while i < len(text):
        start = i
        if text.startswith("//", i):
            end = text.find("\n", i)
            i = len(text) if end < 0 else end
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            assert end >= 0, "Unclosed block comment"
            i = end + 2
        elif text.startswith('@"', i):
            i += 2
            while i < len(text):
                if text.startswith('""', i):
                    i += 2
                elif text[i] == '"':
                    i += 1
                    break
                else:
                    i += 1
            else:
                raise AssertionError("Unclosed verbatim string")
        elif text[i] in ('"', "'"):
            quote = text[i]
            i += 1
            while i < len(text):
                if text[i] == "\\":
                    i += 2
                elif text[i] == quote:
                    i += 1
                    break
                else:
                    assert text[i] not in "\r\n", "Newline in quoted C# literal"
                    i += 1
            else:
                raise AssertionError("Unclosed string/char")
        else:
            i += 1
            continue
        for pos in range(start, i):
            if text[pos] != "\n":
                result[pos] = " "
    return "".join(result)

def method(text, name):
    masked = mask_csharp(text)
    match = re.search(r"\b(?:private|public|internal|protected)\s+(?:static\s+)?[\w<>,\[\] ]+\b" + re.escape(name) + r"\s*\(", masked)
    assert match, "Missing method: " + name
    start = masked.index("{", match.end())
    depth = 1
    end = start + 1
    while depth:
        depth += (masked[end] == "{") - (masked[end] == "}")
        end += 1
    return text[start:end]

def main():
    source = (ROOT / "src/MB_TTMLLyrics.cs").read_text(encoding="utf-8-sig")
    for path in [ROOT / "src/MB_TTMLLyrics.cs", ROOT / "tests/ReleaseRegression.cs"]:
        masked = mask_csharp(path.read_text(encoding="utf-8-sig"))
        stack = []
        for i, c in enumerate(masked):
            if c in "{[(":
                stack.append((c, i))
            elif c in "}])":
                assert stack and stack.pop()[0] == {"}": "{", "]": "[", ")": "("}[c], "Delimiter mismatch: " + str(path)
        assert not stack, "Unclosed delimiter: " + str(path)
        print("PASS lexical delimiters:", path.name)
    ownership = method(source, "IsGlobalSettingKeyV23110")
    for key in ["WordFocus", "TypographyFx", "Artwork", "BackgroundEngine", "BackgroundMotion", "CleanLyricsMode"]:
        assert '"' + key + '"' not in ownership, "Visual state still global: " + key
    assert "ResetProfileOwnedStateV23110" in method(source, "ApplyPresetCoreV23550")
    assert "WriteTextAtomicallyV23550" in method(source, "WriteSettingsSnapshotV23521C")
    assert "WriteTextAtomicallyV23550" in method(source, "SaveFile")
    assert "DeserializeObject" in method(source, "ParseProfileJsonV23550")
    assert "File.Replace" in method(source, "WriteTextAtomicallyV23550")
    assert "Regex.Match" not in method(source, "LoadProfileDictionaryCoreV23110")
    assert 'values["ProfileParentName"] = ""' in method(source, "SaveFile")
    assert "SafeTextBoundaryBeforeV23516" not in source
    assert "FindMaxFittingCharEndV23516" not in source
    assert "first = chosen + 1" in method(source, "AppendOversizeTokenRowsV23516")
    assert "ResolveLongLinePlanningWidthV23523D" in method(source, "GetUniformBlockHeight")
    assert "breaks.Count > 64" in method(source, "BuildBalancedRowsUncachedV2352")
    assert "return BuildGreedySafeRows" not in method(source, "BuildBalancedRows"), "Greedy path bypasses cache"
    assert "TextHint" in method(source, "MakeTypographicMetricKeyV2390")
    assert "new Font(settings.FontName" not in source
    assert "V23.54.1 NO SPOTIFY FONT CONTRACT" in source
    assert 'PluginVersionText = "23.55.0-rc2e-apple-auto-focus-contrast"' in source
    assert 'AppleReferenceMotionV23550' in source
    assert 'UpdateAppleReferenceTweenV23550' in source
    assert 'ComputeAppleReferenceLineAlphaV23550' in source
    assert '"Apple Music"' in source
    assert 'return new string[] {\n                    "Factory 10", "Apple Music", "My Profiles"' in source
    assert 'string[] menuCategories = new string[] { "Factory 10", "Apple Music" };' in source
    assert 'private static string[] AppleMusicProfilesV23550()' in source
    assert 'ApplyAppleMusicProfileContractV23550(profileName);' in method(source, "LoadProfileFromPath")
    apple_contract = method(source, "ApplyAppleMusicProfileContractV23550")
    for token in ['"Apple Precision"', '"Apple Sustain Bloom"', 'ActiveLineAppearanceV2337 = "None"', 'ActiveLineSurfaceV2337 = "None"', 'ActiveLineAccentV2337 = "None"']:
        assert token in apple_contract, "Missing Apple runtime contract token: " + token
    import json
    expected = {
        "Apple · Original Clean": (46,60,8,72),
        "Apple · Depth Focus": (44,58,12,72),
        "Apple · YouLy Depth": (42,56,14,72),
        "Apple · Vocal Flow": (46,60,8,74),
        "Apple · Karaoke Flow": (48,62,6,76),
    }
    for name, vals in expected.items():
        doc = json.loads((ROOT / "profiles" / "AppleMusic" / (name + ".lyricsprofile.json")).read_text(encoding="utf-8-sig"))
        st = doc["settings"]
        assert st["WordFocusEffectV2329"] == "Apple Precision" and st["LongWordFocusModeV2329"] == "Apple Sustain Bloom", name + " focus contract"
        assert (int(st["ApplePastOpacityV23550"]), int(st["AppleUpcomingOpacityV23550"]), int(st["AppleContextFalloffV23550"]), int(st["WordFocusOpacityPercentV2329"])) == vals, name + " contrast calibration"
    assert 'profileCategoryFilter.Equals("My Profiles", StringComparison.OrdinalIgnoreCase) ||' in source
    assert 'profileCategoryFilter.Equals("My Profiles", StringComparison.OrdinalIgnoreCase) && !appleFamilyV23550' not in source
    for token in ["acrylic-safe-cache", "RENDER_PANEL60_SINGLE_SURFACE", "UseV21ExactLyricPipelineV2364", "OnProgressiveStartupTickV23120"]:
        assert token in source, "Missing previous contract: " + token
    print("PASS release source contracts")
    if len(sys.argv) > 1:
        previous = Path(sys.argv[1]).read_text(encoding="utf-8-sig")
        # RC2 intentionally corrects TTML character ranges and nested drawing clips.
        # All other parser behavior, word progress and glyph/wrap measurements stay frozen.
        parser_start = "        private static class LyricsParser"
        ttml_start = "        private static class TtmlParser"
        assert source[source.index(parser_start):source.index(ttml_start)] == previous[previous.index(parser_start):previous.index(ttml_start)], "Non-TTML parser changed"
        for name in ["BuildBalancedRows", "GetUniformBlockHeight", "SafeTextEndsV23550", "MeasureTypographic",
                     "GetWrappedSegmentPieceProgressV23517", "SegmentProgress", "GetKaraokeColor",
                     "ApplyCpuV21TextOnlyStartupV2364", "ApplyFactory10NaturalDesignV23540", "SetGradientFromString"]:
            assert method(source, name) == method(previous, name), "Protected behavior changed: " + name
        for name in ["DrawV21KaraokeSegmentsOptimizedV2367", "DrawWrappedKaraokeSegmentsBatchedV23511"]:
            before = method(previous, name)
            expected = before.replace("g.SetClip(paint.ClipRect);", "g.SetClip(paint.ClipRect, CombineMode.Intersect);")
            assert method(source, name) == expected, "Unexpected karaoke change beyond clip preservation: " + name
        print("PASS protected parser, glyph/wrap, timing, factory designs and CPU baseline; intended karaoke clip correction only")
    print("Source SHA256:", hashlib.sha256((ROOT / "src/MB_TTMLLyrics.cs").read_bytes()).hexdigest())
    print("STATIC ONLY: C# compilation, Windows tests and MusicBee visual acceptance are not covered.")

if __name__ == "__main__":
    main()
